# Honey House — Natural Honey Store

Responsive Thai honey storefront + order desk + Google Sheets Apps Script backend. Static site deployable to Vercel.

## Demo products
- HH-001 น้ำผึ้งดอกลำไย 250 กรัม — ฿159 — opening stock 50
- HH-002 น้ำผึ้งป่า 500 กรัม — ฿279 — opening stock 35

These names, prices and stock quantities are sample data. Replace them with actual business details before accepting real orders.

## Run locally
Open `index.html` in a browser. Without a configured Apps Script URL, checkout is a local demo and stores pending orders in that browser only.

## Connect Google Sheets
1. Create a Google Sheet.
2. Open **Extensions → Apps Script** and paste `google-apps-script/Code.gs`.
3. In Apps Script **Project Settings → Script properties**, add `ADMIN_TOKEN` with a long random secret. Keep it private.
4. Run `setupSheets()` once and approve the requested permissions. It creates `Products` and `Orders` sheets and inserts sample SKUs.
5. Deploy as **Web app**, execute as **Me**, and set access to **Anyone**. Copy the deployment URL.
6. In `app.js`, replace `API_URL:''` with that URL. Set `LINE_URL` to your shop's official LINE OA URL.
7. Redeploy the Apps Script web app after backend changes.

**Important security note:** this starter exposes order submission publicly, which is expected for checkout. The admin token protects listing and status changes. For a production store, add stronger authentication, spam/rate limiting, payment verification, server-side SKU/price validation, and inventory reservation. Do not store the admin token in the public storefront JavaScript; use a separate protected admin configuration or a server-side API proxy before real production use. This starter's admin token field is a teaching/demo convenience and should not be treated as production-grade secret storage.

## Order workflow
- Customer selects SKU(s), enters recipient details and submits checkout.
- Google Apps Script appends the order to `Orders`.
- Open `admin.html`, enter admin token, and load orders.
- Use **หยิบ/แพ็ก** to view the picking list; verify each SKU and quantity physically.
- Change status to `กำลังหยิบสินค้า`, then `แพ็กสินค้าแล้ว`.
- Use **ใบจ่าหน้า** to print a basic recipient label on A4/label stock.
- After handing the parcel to the carrier and obtaining a tracking number, update the order status to `จัดส่งแล้ว`.

The printable label is a basic store label, not a carrier-issued shipping label or postage-paid waybill. To generate official labels and tracking numbers, integrate the selected carrier's shipping API/account.

## Deploy to GitHub + Vercel
1. Create a new GitHub repository named `honey-house` and upload all project files, preserving folders.
2. In Vercel, **Add New → Project**, import `honey-house` from GitHub.
3. Framework preset: **Other**; build command: leave blank; output directory: `.` (root).
4. Deploy. Vercel provides a `*.vercel.app` URL. Add a custom domain in Project → Settings → Domains if desired.
5. Every push to the connected production branch triggers a new deployment.

## File layout
```text
honey-house/
├── index.html
├── admin.html
├── styles.css
├── app.js
├── public/
│   └── images/       # put product photos here
├── google-apps-script/
│   └── Code.gs
└── README.md
```
