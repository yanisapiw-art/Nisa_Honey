/** Honey House Google Sheets API
 * 1) Create a Google Sheet, open Extensions > Apps Script, paste this file.
 * 2) Project Settings > Script Properties: set ADMIN_TOKEN to a long random secret.
 * 3) Run setupSheets() once and authorize.
 * 4) Deploy > New deployment > Web app; Execute as Me; access Anyone.
 * 5) Copy deployment URL into CONFIG.API_URL in app.js.
 */
const SHEETS={Products:['SKU','Name','Size','Price','Stock','Active'],Orders:['OrderID','CreatedAt','CustomerName','Phone','Address','Postcode','Note','ItemsJSON','Total','Status']};
function setupSheets(){const ss=SpreadsheetApp.getActive();Object.entries(SHEETS).forEach(([name,headers])=>{let sh=ss.getSheetByName(name)||ss.insertSheet(name);if(sh.getLastRow()===0)sh.appendRow(headers)});const p=ss.getSheetByName('Products');if(p.getLastRow()===1)p.getRange(2,1,2,6).setValues([['HH-001','น้ำผึ้งดอกลำไย','250 กรัม',159,50,true],['HH-002','น้ำผึ้งป่า','500 กรัม',279,35,true]]);}
function doPost(e){try{const data=JSON.parse((e.parameter&&e.parameter.payload)||'{}');if(data.action==='createOrder')return json_(createOrder_(data));if(data.action==='updateStatus'){auth_(data.token);return json_(updateStatus_(data))}return json_({ok:false,error:'Unknown action'})}catch(err){return json_({ok:false,error:String(err)})}}
function doGet(e){const q=e.parameter||{};if(q.action!=='listOrders')return json_({ok:true,service:'Honey House API'});auth_(q.token);const orders=listOrders_();const body=JSON.stringify({ok:true,orders});if(q.callback)return ContentService.createTextOutput(q.callback+'('+body+')').setMimeType(ContentService.MimeType.JAVASCRIPT);return json_({ok:true,orders});}
function createOrder_(d){const ss=SpreadsheetApp.getActive();const sh=ss.getSheetByName('Orders');if(!sh)throw new Error('Run setupSheets() first');if(!d.customer||!d.items||!d.items.length)throw new Error('Missing customer or items');const id='HH-'+Utilities.formatDate(new Date(),'Asia/Bangkok','yyyyMMdd-HHmmss')+'-'+Math.floor(Math.random()*900+100);const c=d.customer;sh.appendRow([id,new Date(),c.name,c.phone,c.address,c.postcode,c.note||'',JSON.stringify(d.items),Number(d.total)||0,'รอรับออเดอร์']);return {ok:true,orderId:id}}
function listOrders_(){const sh=SpreadsheetApp.getActive().getSheetByName('Orders');if(!sh||sh.getLastRow()<2)return [];const rows=sh.getRange(2,1,sh.getLastRow()-1,10).getValues();return rows.map(r=>({orderId:r[0],createdAt:r[1],customer:{name:r[2],phone:r[3],address:r[4],postcode:r[5],note:r[6]},items:JSON.parse(r[7]||'[]'),total:r[8],status:r[9]})).reverse()}
function updateStatus_(d){const sh=SpreadsheetApp.getActive().getSheetByName('Orders');const rows=sh.getRange(2,1,Math.max(0,sh.getLastRow()-1),10).getValues();const i=rows.findIndex(r=>r[0]===d.orderId);if(i<0)throw new Error('Order not found');sh.getRange(i+2,10).setValue(d.status);return {ok:true}}
function auth_(token){const expected=PropertiesService.getScriptProperties().getProperty('ADMIN_TOKEN');if(!expected||token!==expected)throw new Error('Unauthorized')}
function json_(obj){return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON)}
